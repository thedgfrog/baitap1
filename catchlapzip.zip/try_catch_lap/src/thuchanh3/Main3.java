package thuchanh3;

import java.util.Scanner;

public class Main3 {
	
public static void check(int a,int b,int c) {
	if(a>b&&a>c&&a==Math.sqrt(b*b+c*c)) {
		System.out.println(" tam giac vuong");
	}else if(b>a&&b>c&&b==Math.sqrt(a*a+c*c)) {
		System.out.println(" tam giac vuong");
	}else if(c>a&&c>b&&c==Math.sqrt(b*b+a*a)) {
		System.out.println(" tam giac vuong");

	}
	else if(a==b && a==c) {
		System.out.println(" tam giac deu");
	}else if(a==b||a==c||b==c) {
		System.out.println(" tam giac can");
	}else System.out.println(" tam giac thuong");
		
	}

	static Scanner sc=new Scanner(System.in);
public static void main(String[] args) {
int arr[]=new int[3];



try {
	for(int i=0;i<arr.length;i++) {arr[i]=sc.nextInt();}
	for(int i=0;i<arr.length;i++) {
		if(arr[i]==0) throw new Exception("InvalidinTriangle");
	}
	if(arr.length!=3) throw new Exception(" Arithmatic ");
}catch(Exception e) {
	System.out.println(" arror :"+e.getMessage());
}finally {
	check(arr[0],arr[1],arr[2]);
}
	
		

}
	}


