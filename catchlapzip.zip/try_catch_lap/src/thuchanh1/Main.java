package thuchanh1;

import java.util.Scanner;

public class Main {
	  static Scanner sc = new Scanner(System.in);

	    public static void main(String[] args) {
	        int arr[] = new int[3]; // Mảng để lưu trữ 3 hệ số a, b, c

	        System.out.println("PHUONG TRINH BAC HAI.");

	        // Nhập a, b, c từ người dùng
	        while (true) {
	            System.out.print("Nhập 3 số (a, b, c): ");
	            String str = sc.nextLine();
	            String sarr[] = str.split(" "); // Tách chuỗi nhập vào thành mảng

	            try {
	                // Kiểm tra nhập đúng 3 số
	                if (sarr.length != 3) {
	                    throw new Exception("Cần nhập đúng 3 số.");
	                }

	                // Chuyển đổi đầu vào thành các số nguyên
	                for (int i = 0; i < arr.length; i++) {
	                    arr[i] = Integer.parseInt(sarr[i]);
	                }

	                break; // Thoát vòng lặp nếu nhập đúng 3 số
	            } catch (Exception e) {
	                System.out.println(e.getMessage()); // In thông báo nếu nhập sai
	            }
	        }

	        // Gán lại a, b, c từ mảng arr[]
	        double a = arr[0], b = arr[1], c = arr[2];
	        double x1, x2;

	        // Kiểm tra a == 0, vì nếu a = 0 thì không phải phương trình bậc hai
	        if (a == 0) {
	            System.out.println("Giá trị a không được bằng 0.");
	            return; // Dừng chương trình nếu a = 0
	        }

	        // Tính delta
	        double delta = b * b - 4 * a * c;

	        // Kiểm tra nghiệm phương trình bậc hai
	        if (delta < 0) {
	            System.out.println("Phương trình vô nghiệm (delta < 0).");
	        } else if (delta == 0) {
	            x1 = -b / (2 * a); // Nghiệm kép
	            System.out.println("Nghiệm kép: x1 = " + x1);
	        } else {
	            // Tính 2 nghiệm khi delta > 0
	            x1 = (-b - Math.sqrt(delta)) / (2 * a);
	            x2 = (-b + Math.sqrt(delta)) / (2 * a);
	            System.out.println("x1 = " + x1);
	            System.out.println("x2 = " + x2);
	        }
	    }

	

}
