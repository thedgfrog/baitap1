package thuchanh2;

import java.util.Scanner;

public class Main2 {
static Scanner sc=new Scanner(System.in);
public static void main(String[] args) throws Exception {
	String str=sc.nextLine();
	
	String sarr[]=str.split(" ");
	String arr[]=new String[3];
	
	 try {
         if (sarr.length != 3) {
             throw new Exception("Không đủ 3 phần tử");
         }

         for (int i = 0; i < sarr.length; i++) {
             arr[i] = sarr[i];
         }
     } catch (Exception e) {
         System.out.println(e.getMessage());
         return; 
     } double c = 0;
	 double a=Integer.parseInt(arr[0]);
		double b=Integer.parseInt(arr[2]);
	 try { if(arr[1].contains("+")) {
		 c=a+b;
	 }else if(arr[1].contains("-")) {
		 c=a-b;
	 }else if(arr[1].contains("*")) {
		 c=a*b;
	 }else if(arr[1].contains("/")) {
		 c=a/b;
		 if(b==0) throw new ArithmeticException(" loi mau");
	 }else throw new ArithmeticException(" khac ki tu");
		 
	 }catch(Exception e) {
		 System.out.println(e.getMessage());
	 }
	System.out.println("kq la : "+c);
	
		
	}}
	
	

